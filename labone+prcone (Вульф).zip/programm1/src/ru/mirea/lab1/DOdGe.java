package ru.mirea.lab1;
import java.util.Scanner;

public class DOdGe {
    Scanner scr = new Scanner(System.in);
    private String name;
    private String color;
    private int weight;

    public DOdGe(String name1, String color1, int weight1){
        name = name1;
        weight = weight1;
        color = color1;

    };
    public String toString(){
        String info;
        info = "Кличка:" + " " + name + ", " + "Вес:" + " " + weight + ", " + "Окрас:" + " "+ color;
        return info;
    };
}
