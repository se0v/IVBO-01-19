package ru.mirea.lab1;
import ru.mirea.lab1.DOdGe;

import java.util.Scanner;

public class classtester {
    public static void main(String[] args){
        Scanner scr = new Scanner(System.in);
        DOdGe Dodge= new DOdGe("Dodge", "черно-белый", 50);
        System.out.print(Dodge);

    }
}