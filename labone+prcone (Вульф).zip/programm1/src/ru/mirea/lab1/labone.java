package ru.mirea.lab1;
import java.util.Scanner;
    public class labone {
        public static void main(String[] args){

            Scanner scr = new Scanner(System.in);
            int size = 0;
            int sum = 0;

            System.out.print("Array size: ");
            size = scr.nextInt();
            int[] a = new int[size];
            System.out.print("Array elements: ");
            for(int i = 0; i<size; i++) {
                a[i] = scr.nextInt();
                sum = sum + a[i];
            }
            System.out.print("Sum of array elements: ");
            System.out.print(sum+ "\n");

            //2
            System.out.print("Cmd args: ");
            for(int i = 0; i<a.length; i++) {
                System.out.print(a[i]+ " ");
            }

            //3
            double[] mass = new double[10];
            for(int i = 0; i<10; i++)
            {
                mass[i] = (double)1/i;
            }
            System.out.print("\n"+"10 harmonic numbers: ");
            for(int i = 0; i<10; i++)
            {
                System.out.print(mass[i] + " ");
            }

            //4
            System.out.print("\n"+"Unsorted array of random numbers: ");
            int[] mass2 = new int[10];
            for(int i = 0; i<10; i++)
            {
                mass2[i] = (int)(Math.random()*100);
                System.out.print(mass2[i] + " ");
            }
            int buff;
            for(int j=0; j<10;j++)
            {
            for(int i = 0; i<9; i++)
            {
                if(mass2[i]>mass2[i+1])
                {
                    buff = mass2[i];
                    mass2[i] = mass2[i+1];
                    mass2[i+1] = buff;
                }
            }
            }
            System.out.print("\n"+"Sort array:  ");
            for(int i = 0; i<10; i++)
            {
                System.out.print(mass2[i] + " ");
            }

            //5
            System.out.print("\n"+"Number:  ");
            size = scr.nextInt();
            System.out.print("Factorial: " + fact(size));
            }
            public static int fact(int f) {
                int s1 = 1;
                for(int i = 1; i<=f;i++) {
                    s1 = s1 * i;
                }
                return s1;
            }
        }

